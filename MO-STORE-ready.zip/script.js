const WHATSAPP_NUMBER = "201000000000"; // غيّر الرقم لاحقًا إلى رقم المتجر
const products = [
{id:1,name:"Smart Watch",price:899,cat:"electronics",img:"https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=700&q=80"},
{id:2,name:"Wireless Headphones",price:1299,cat:"electronics",img:"https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=700&q=80"},
{id:3,name:"Classic T-Shirt",price:499,cat:"fashion",img:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=700&q=80"},
{id:4,name:"Sneakers",price:1499,cat:"fashion",img:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=700&q=80"},
{id:5,name:"Sunglasses",price:399,cat:"accessories",img:"https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=700&q=80"},
{id:6,name:"Leather Bag",price:999,cat:"accessories",img:"https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=700&q=80"}];
let category="all",cart=[];
function setCategory(c,btn){category=c;document.querySelectorAll(".filters button").forEach(x=>x.classList.remove("active"));btn.classList.add("active");renderProducts()}
function renderProducts(){const q=document.getElementById("search").value.trim().toLowerCase();const list=products.filter(p=>(category==="all"||p.cat===category)&&p.name.toLowerCase().includes(q));document.getElementById("productsGrid").innerHTML=list.length?list.map(p=>`<article class="card"><img src="${p.img}" alt="${p.name}"><div class="info"><h3>${p.name}</h3><div class="price">${p.price} جنيه</div><button class="add" onclick="add(${p.id})">أضف للسلة 🛒</button></div></article>`).join(""):`<p class="empty">لا توجد منتجات مطابقة.</p>`}
function add(id){cart.push(products.find(p=>p.id===id));updateCart();openCart()}
function remove(i){cart.splice(i,1);updateCart()}
function updateCart(){document.getElementById("cartCount").textContent=cart.length;const box=document.getElementById("cartItems");let total=0;box.innerHTML=cart.length?cart.map((p,i)=>{total+=p.price;return `<div class="cart-row"><div><b>${p.name}</b><br>${p.price} جنيه</div><button class="remove" onclick="remove(${i})">حذف</button></div>`}).join(""):`<div class="empty">السلة فارغة.</div>`;document.getElementById("cartTotal").textContent=total}
function openCart(){document.getElementById("overlay").classList.add("show")}
function closeCart(e){if(!e||e.target.id==="overlay")document.getElementById("overlay").classList.remove("show")}
function checkout(){if(!cart.length)return alert("السلة فارغة");let total=cart.reduce((s,p)=>s+p.price,0);let msg="مرحبًا، أريد الطلب من MO STORE:%0A%0A"+cart.map(p=>`- ${p.name} — ${p.price} جنيه`).join("%0A")+`%0A%0Aالإجمالي: ${total} جنيه`;window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`,"_blank")}
document.getElementById("whatsappLink").href=`https://wa.me/${WHATSAPP_NUMBER}`;
renderProducts();updateCart();